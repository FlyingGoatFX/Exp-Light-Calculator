This .EXE works better (probably) with older OS, but requires separate installation of .NET framework (3.5 or 4.0+) 
and is strictly Windows only.  Files in this package must remain in same folder to run. 

Windows XP_SP3+/7/8.x/10/11, x86/x64, 290KB (not including .NET installation)

I've only tested with an iffy VM, so YMMV.

There are two versions enclosed: one for .NET 4.0+, one for .NET 3.5