This .EXE works better (probably) with older OS, but requires separate installation of .NET framework (ideally 4.x+) 
and is strictly Windows only.  Files in this package must remain in same folder to run. 

Windows XP_SP3+/7/8.x/10/11, x86/x64, 150KB (not including .NET installation)

I've only tested with an iffy VM, so YMMV.